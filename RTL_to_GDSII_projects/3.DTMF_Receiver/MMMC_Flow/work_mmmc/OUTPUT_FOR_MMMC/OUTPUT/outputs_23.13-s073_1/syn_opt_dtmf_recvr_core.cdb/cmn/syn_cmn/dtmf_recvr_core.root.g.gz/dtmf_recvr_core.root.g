######################################################################

# Created by Genus(TM) Synthesis Solution 23.13-s073_1 on Wed Jun 24 01:11:26 IST 2026

# This file contains the Genus script for design:dtmf_recvr_core

######################################################################

set_db -quiet information_level 9
set_db -quiet init_lib_search_path {. ../}
set_db -quiet design_mode_process 60.0
set_db -quiet phys_assume_met_fill 0.0
set_db -quiet map_placed_for_route_early_global false
set_db -quiet phys_use_invs_extraction true
set_db -quiet phys_route_time_out 120.0
set_db -quiet db_units 2000
set_db -quiet capacitance_per_unit_length_mmmc {}
set_db -quiet resistance_per_unit_length_mmmc {}
set_db -quiet lp_insert_clock_gating true
set_db -quiet runtime_by_stage {{PBS_Generic-earlyCG 3 75 2.9999990000000025 58.999999} {to_generic 88 170 90 156} {first_condense 58 235 70 235} {PBS_Generic_Opt-Post 157 237 158.90513900000002 221.867892} {{PBS_Generic-Postgen HBO Optimizations} 0 237 0.0 221.867892} {PBS_Generic-earlyCG_cleanup 1 241 1.0 226.867892} {PBS_TechMap-Start 0 246 0.0 229.46065} {{PBS_TechMap-Premap HBO Optimizations} 1 247 1.0 230.46065} {first_condense 50 298 74 321} {reify 116 414 280 601} {{PBS_Techmap-Global Mapping} 167 414 169.6796200000001 400.1402700000001} {{PBS_TechMap-Datapath Postmap Operations} 44 458 59.90053899999958 460.0408089999997} {{PBS_TechMap-Postmap HBO Optimizations} 0 458 0.7254129999999464 460.76622199999963} {{PBS_TechMap-Postmap Clock Gating} 1 459 1.0 461.76622199999963} {{PBS_TechMap-Postmap Cleanup} 4 463 3.534490000000119 465.30071199999975} {PBS_Techmap-Post_MBCI 0 463 0.0 465.30071199999975} {incr_opt 59 526 66 741} }
set_db -quiet timing_adjust_tns_of_complex_flops false
set_db -quiet tim_complex_use_dense false
set_db -quiet tim_complex_use_prevs false
set_db -quiet dft_use_ungated_clock_for_testpoint true
set_db -quiet tinfo_tstamp_file .rs_user5.tstamp
set_db -quiet common_preserve_skip_internal true
set_db -quiet script_search_path { . }
set_db -quiet syn_map_effort medium
set_db -quiet syn_opt_effort medium
set_db -quiet use_area_from_lef true
set_db -quiet shrink_factor 0.9
set_db -quiet read_qrc_tech_file_rc_corner true
set_db -quiet inst:dtmf_recvr_core/PLLCLK_INST .hdl_instantiated true
set_db -quiet hinst:dtmf_recvr_core/PM_INST .hdl_instantiated true
set_db -quiet inst:dtmf_recvr_core/RAM_128x16_TEST_INST_RAM_128x16_INST .hdl_instantiated true
set_db -quiet inst:dtmf_recvr_core/RAM_256x16_TEST_INST_RAM_256x16_INST .hdl_instantiated true
set_db -quiet inst:dtmf_recvr_core/ROM_512x16_0_INST .hdl_instantiated true
set_db -quiet hinst:dtmf_recvr_core/SPI_INST .hdl_instantiated true
set_db -quiet hinst:dtmf_recvr_core/TDSP_CORE_INST_ACCUM_STAT_INST .hdl_instantiated true
set_db -quiet hinst:dtmf_recvr_core/TDSP_CORE_INST_DATA_BUS_MACH_INST .hdl_instantiated true
set_db -quiet hinst:dtmf_recvr_core/TDSP_CORE_INST_DECODE_INST .hdl_instantiated true
set_db -quiet hinst:dtmf_recvr_core/TDSP_CORE_INST_PORT_BUS_MACH_INST .hdl_instantiated true
set_db -quiet hinst:dtmf_recvr_core/TDSP_CORE_INST_PROG_BUS_MACH_INST .hdl_instantiated true
set_db -quiet hinst:dtmf_recvr_core/TDSP_CORE_INST_TDSP_CORE_MACH_INST .hdl_instantiated true
set_db -quiet hinst:dtmf_recvr_core/TEST_CONTROL_INST .hdl_instantiated true
# there is no hdl_instantiated attribute information available
set_db -quiet source_verbose true
