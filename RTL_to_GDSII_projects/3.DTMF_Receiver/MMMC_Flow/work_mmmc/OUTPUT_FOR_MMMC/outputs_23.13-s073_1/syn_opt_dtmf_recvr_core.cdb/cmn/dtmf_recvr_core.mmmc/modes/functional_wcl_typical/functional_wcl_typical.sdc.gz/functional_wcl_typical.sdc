# ####################################################################

#  Created by Genus(TM) Synthesis Solution 23.13-s073_1 on Wed Jun 24 01:10:49 IST 2026

# ####################################################################

set sdc_version 2.0

set_units -capacitance 1000fF
set_units -time 1000ps

# Set the current design
current_design dtmf_recvr_core

set_case_analysis 0 [get_ports test_mode]
set_case_analysis 0 [get_ports scan_en]
create_clock -name "refclk" -period 6.0 -waveform {0.0 3.0} [get_ports refclk]
create_clock -name "m_clk" -period 6.0 -waveform {0.0 3.0} [get_pins TEST_CONTROL_INST/m_clk]
create_clock -name "m_rcc_clk" -period 16.0 -waveform {0.0 8.0} [get_pins TEST_CONTROL_INST/m_rcc_clk]
create_clock -name "m_spi_clk" -period 16.0 -waveform {0.0 8.0} [get_pins TEST_CONTROL_INST/m_spi_clk]
create_clock -name "m_dsram_clk" -period 16.0 -waveform {0.0 8.0} [get_pins TEST_CONTROL_INST/m_dsram_clk]
create_clock -name "m_ram_clk" -period 16.0 -waveform {0.0 8.0} [get_pins TEST_CONTROL_INST/m_ram_clk]
create_clock -name "m_digit_clk" -period 16.0 -waveform {0.0 8.0} [get_pins TEST_CONTROL_INST/m_digit_clk]
create_clock -name "clk2x" -period 6.0 -waveform {0.0 3.0} [get_pins PLLCLK_INST/clk2x]
group_path -name cg_enable_group_m_clk -through [list \
  [get_pins PM_INST/RC_CG_HIER_INST12/enable]  \
  [get_pins PM_INST/RC_CG_HIER_INST12/RC_CGIC_INST/E]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST14/enable]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST14/RC_CGIC_INST/E]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST15/enable]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST15/RC_CGIC_INST/E]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST16/enable]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST16/RC_CGIC_INST/E]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST17/enable]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST17/RC_CGIC_INST/E]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST18/enable]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST18/RC_CGIC_INST/E]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST19/enable]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST19/RC_CGIC_INST/E]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST20/enable]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST20/RC_CGIC_INST/E]  \
  [get_pins SPI_INST/RC_CG_HIER_INST30/enable]  \
  [get_pins SPI_INST/RC_CG_HIER_INST30/RC_CGIC_INST/E]  \
  [get_pins RC_CG_HIER_INST2/enable]  \
  [get_pins RC_CG_HIER_INST2/RC_CGIC_INST/E]  \
  [get_pins PM_INST/RC_CG_HIER_INST12/enable]  \
  [get_pins PM_INST/RC_CG_HIER_INST12/RC_CGIC_INST/E]  \
  [get_pins RC_CG_HIER_INST2/enable]  \
  [get_pins RC_CG_HIER_INST2/RC_CGIC_INST/E]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST14/enable]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST14/RC_CGIC_INST/E]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST15/enable]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST15/RC_CGIC_INST/E]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST16/enable]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST16/RC_CGIC_INST/E]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST17/enable]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST17/RC_CGIC_INST/E]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST18/enable]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST18/RC_CGIC_INST/E]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST19/enable]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST19/RC_CGIC_INST/E]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST20/enable]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST20/RC_CGIC_INST/E]  \
  [get_pins SPI_INST/RC_CG_HIER_INST30/enable]  \
  [get_pins SPI_INST/RC_CG_HIER_INST30/RC_CGIC_INST/E]  \
  [get_pins PM_INST/RC_CG_HIER_INST12/enable]  \
  [get_pins PM_INST/RC_CG_HIER_INST12/RC_CGIC_INST/E]  \
  [get_pins RC_CG_HIER_INST2/enable]  \
  [get_pins RC_CG_HIER_INST2/RC_CGIC_INST/E]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST14/enable]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST14/RC_CGIC_INST/E]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST15/enable]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST15/RC_CGIC_INST/E]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST16/enable]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST16/RC_CGIC_INST/E]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST17/enable]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST17/RC_CGIC_INST/E]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST18/enable]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST18/RC_CGIC_INST/E]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST19/enable]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST19/RC_CGIC_INST/E]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST20/enable]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST20/RC_CGIC_INST/E]  \
  [get_pins SPI_INST/RC_CG_HIER_INST30/enable]  \
  [get_pins SPI_INST/RC_CG_HIER_INST30/RC_CGIC_INST/E] ]
group_path -name cg_enable_group_m_rcc_clk -through [list \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST21/enable]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST21/RC_CGIC_INST/E]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST22/enable]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST22/RC_CGIC_INST/E]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST23/enable]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST23/RC_CGIC_INST/E]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST24/enable]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST24/RC_CGIC_INST/E]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST25/enable]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST25/RC_CGIC_INST/E]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST26/enable]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST26/RC_CGIC_INST/E]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST27/enable]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST27/RC_CGIC_INST/E]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST28/enable]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST28/RC_CGIC_INST/E]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST21/enable]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST21/RC_CGIC_INST/E]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST22/enable]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST22/RC_CGIC_INST/E]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST23/enable]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST23/RC_CGIC_INST/E]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST24/enable]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST24/RC_CGIC_INST/E]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST25/enable]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST25/RC_CGIC_INST/E]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST26/enable]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST26/RC_CGIC_INST/E]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST27/enable]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST27/RC_CGIC_INST/E]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST28/enable]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST28/RC_CGIC_INST/E]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST21/enable]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST21/RC_CGIC_INST/E]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST22/enable]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST22/RC_CGIC_INST/E]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST23/enable]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST23/RC_CGIC_INST/E]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST24/enable]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST24/RC_CGIC_INST/E]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST25/enable]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST25/RC_CGIC_INST/E]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST26/enable]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST26/RC_CGIC_INST/E]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST27/enable]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST27/RC_CGIC_INST/E]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST28/enable]  \
  [get_pins RESULTS_CONV_INST_RC_CG_HIER_INST28/RC_CGIC_INST/E] ]
group_path -name cg_enable_group_m_spi_clk -through [list \
  [get_pins SPI_INST/RC_CG_HIER_INST29/enable]  \
  [get_pins SPI_INST/RC_CG_HIER_INST29/RC_CGIC_INST/E]  \
  [get_pins SPI_INST/RC_CG_HIER_INST29/enable]  \
  [get_pins SPI_INST/RC_CG_HIER_INST29/RC_CGIC_INST/E]  \
  [get_pins SPI_INST/RC_CG_HIER_INST29/enable]  \
  [get_pins SPI_INST/RC_CG_HIER_INST29/RC_CGIC_INST/E] ]
group_path -name cg_enable_group_clk2x -through [list \
  [get_pins TDSP_CORE_INST_DATA_BUS_MACH_INST/RC_CG_HIER_INST0/enable]  \
  [get_pins TDSP_CORE_INST_DATA_BUS_MACH_INST/RC_CG_HIER_INST0/RC_CGIC_INST/E]  \
  [get_pins TDSP_CORE_INST_DECODE_INST/RC_CG_HIER_INST1/enable]  \
  [get_pins TDSP_CORE_INST_DECODE_INST/RC_CG_HIER_INST1/RC_CGIC_INST/E]  \
  [get_pins TDSP_CORE_INST_DECODE_INST/RC_CG_HIER_INST33/enable]  \
  [get_pins TDSP_CORE_INST_DECODE_INST/RC_CG_HIER_INST33/RC_CGIC_INST/E]  \
  [get_pins TDSP_CORE_INST_EXECUTE_INST_RC_CG_HIER_INST3/enable]  \
  [get_pins TDSP_CORE_INST_EXECUTE_INST_RC_CG_HIER_INST3/RC_CGIC_INST/E]  \
  [get_pins TDSP_CORE_INST_EXECUTE_INST_RC_CG_HIER_INST4/enable]  \
  [get_pins TDSP_CORE_INST_EXECUTE_INST_RC_CG_HIER_INST4/RC_CGIC_INST/E]  \
  [get_pins TDSP_CORE_INST_EXECUTE_INST_RC_CG_HIER_INST5/enable]  \
  [get_pins TDSP_CORE_INST_EXECUTE_INST_RC_CG_HIER_INST5/RC_CGIC_INST/E]  \
  [get_pins TDSP_CORE_INST_EXECUTE_INST_RC_CG_HIER_INST6/enable]  \
  [get_pins TDSP_CORE_INST_EXECUTE_INST_RC_CG_HIER_INST6/RC_CGIC_INST/E]  \
  [get_pins TDSP_CORE_INST_EXECUTE_INST_RC_CG_HIER_INST7/enable]  \
  [get_pins TDSP_CORE_INST_EXECUTE_INST_RC_CG_HIER_INST7/RC_CGIC_INST/E]  \
  [get_pins TDSP_CORE_INST_EXECUTE_INST_RC_CG_HIER_INST8/enable]  \
  [get_pins TDSP_CORE_INST_EXECUTE_INST_RC_CG_HIER_INST8/RC_CGIC_INST/E]  \
  [get_pins TDSP_CORE_INST_EXECUTE_INST_RC_CG_HIER_INST9/enable]  \
  [get_pins TDSP_CORE_INST_EXECUTE_INST_RC_CG_HIER_INST9/RC_CGIC_INST/E]  \
  [get_pins TDSP_CORE_INST_EXECUTE_INST_RC_CG_HIER_INST10/enable]  \
  [get_pins TDSP_CORE_INST_EXECUTE_INST_RC_CG_HIER_INST10/RC_CGIC_INST/E]  \
  [get_pins TDSP_CORE_INST_EXECUTE_INST_RC_CG_HIER_INST34/enable]  \
  [get_pins TDSP_CORE_INST_EXECUTE_INST_RC_CG_HIER_INST34/RC_CGIC_INST/E]  \
  [get_pins TDSP_CORE_INST_EXECUTE_INST_RC_CG_HIER_INST35/enable]  \
  [get_pins TDSP_CORE_INST_EXECUTE_INST_RC_CG_HIER_INST35/RC_CGIC_INST/E]  \
  [get_pins TDSP_CORE_INST_PORT_BUS_MACH_INST/RC_CG_HIER_INST11/enable]  \
  [get_pins TDSP_CORE_INST_PORT_BUS_MACH_INST/RC_CG_HIER_INST11/RC_CGIC_INST/E]  \
  [get_pins TDSP_CORE_INST_PROG_BUS_MACH_INST/RC_CG_HIER_INST13/enable]  \
  [get_pins TDSP_CORE_INST_PROG_BUS_MACH_INST/RC_CG_HIER_INST13/RC_CGIC_INST/E]  \
  [get_pins TDSP_CORE_INST_TDSP_CORE_MACH_INST/RC_CG_HIER_INST31/enable]  \
  [get_pins TDSP_CORE_INST_TDSP_CORE_MACH_INST/RC_CG_HIER_INST31/RC_CGIC_INST/E]  \
  [get_pins TDSP_CORE_INST_DATA_BUS_MACH_INST/RC_CG_HIER_INST0/enable]  \
  [get_pins TDSP_CORE_INST_DATA_BUS_MACH_INST/RC_CG_HIER_INST0/RC_CGIC_INST/E]  \
  [get_pins TDSP_CORE_INST_DECODE_INST/RC_CG_HIER_INST1/enable]  \
  [get_pins TDSP_CORE_INST_DECODE_INST/RC_CG_HIER_INST1/RC_CGIC_INST/E]  \
  [get_pins TDSP_CORE_INST_DECODE_INST/RC_CG_HIER_INST33/enable]  \
  [get_pins TDSP_CORE_INST_DECODE_INST/RC_CG_HIER_INST33/RC_CGIC_INST/E]  \
  [get_pins TDSP_CORE_INST_EXECUTE_INST_RC_CG_HIER_INST3/enable]  \
  [get_pins TDSP_CORE_INST_EXECUTE_INST_RC_CG_HIER_INST3/RC_CGIC_INST/E]  \
  [get_pins TDSP_CORE_INST_EXECUTE_INST_RC_CG_HIER_INST4/enable]  \
  [get_pins TDSP_CORE_INST_EXECUTE_INST_RC_CG_HIER_INST4/RC_CGIC_INST/E]  \
  [get_pins TDSP_CORE_INST_EXECUTE_INST_RC_CG_HIER_INST5/enable]  \
  [get_pins TDSP_CORE_INST_EXECUTE_INST_RC_CG_HIER_INST5/RC_CGIC_INST/E]  \
  [get_pins TDSP_CORE_INST_EXECUTE_INST_RC_CG_HIER_INST6/enable]  \
  [get_pins TDSP_CORE_INST_EXECUTE_INST_RC_CG_HIER_INST6/RC_CGIC_INST/E]  \
  [get_pins TDSP_CORE_INST_EXECUTE_INST_RC_CG_HIER_INST7/enable]  \
  [get_pins TDSP_CORE_INST_EXECUTE_INST_RC_CG_HIER_INST7/RC_CGIC_INST/E]  \
  [get_pins TDSP_CORE_INST_EXECUTE_INST_RC_CG_HIER_INST8/enable]  \
  [get_pins TDSP_CORE_INST_EXECUTE_INST_RC_CG_HIER_INST8/RC_CGIC_INST/E]  \
  [get_pins TDSP_CORE_INST_EXECUTE_INST_RC_CG_HIER_INST9/enable]  \
  [get_pins TDSP_CORE_INST_EXECUTE_INST_RC_CG_HIER_INST9/RC_CGIC_INST/E]  \
  [get_pins TDSP_CORE_INST_EXECUTE_INST_RC_CG_HIER_INST10/enable]  \
  [get_pins TDSP_CORE_INST_EXECUTE_INST_RC_CG_HIER_INST10/RC_CGIC_INST/E]  \
  [get_pins TDSP_CORE_INST_EXECUTE_INST_RC_CG_HIER_INST34/enable]  \
  [get_pins TDSP_CORE_INST_EXECUTE_INST_RC_CG_HIER_INST34/RC_CGIC_INST/E]  \
  [get_pins TDSP_CORE_INST_EXECUTE_INST_RC_CG_HIER_INST35/enable]  \
  [get_pins TDSP_CORE_INST_EXECUTE_INST_RC_CG_HIER_INST35/RC_CGIC_INST/E]  \
  [get_pins TDSP_CORE_INST_PORT_BUS_MACH_INST/RC_CG_HIER_INST11/enable]  \
  [get_pins TDSP_CORE_INST_PORT_BUS_MACH_INST/RC_CG_HIER_INST11/RC_CGIC_INST/E]  \
  [get_pins TDSP_CORE_INST_PROG_BUS_MACH_INST/RC_CG_HIER_INST13/enable]  \
  [get_pins TDSP_CORE_INST_PROG_BUS_MACH_INST/RC_CG_HIER_INST13/RC_CGIC_INST/E]  \
  [get_pins TDSP_CORE_INST_TDSP_CORE_MACH_INST/RC_CG_HIER_INST31/enable]  \
  [get_pins TDSP_CORE_INST_TDSP_CORE_MACH_INST/RC_CG_HIER_INST31/RC_CGIC_INST/E]  \
  [get_pins TDSP_CORE_INST_DATA_BUS_MACH_INST/RC_CG_HIER_INST0/enable]  \
  [get_pins TDSP_CORE_INST_DATA_BUS_MACH_INST/RC_CG_HIER_INST0/RC_CGIC_INST/E]  \
  [get_pins TDSP_CORE_INST_DECODE_INST/RC_CG_HIER_INST1/enable]  \
  [get_pins TDSP_CORE_INST_DECODE_INST/RC_CG_HIER_INST1/RC_CGIC_INST/E]  \
  [get_pins TDSP_CORE_INST_DECODE_INST/RC_CG_HIER_INST33/enable]  \
  [get_pins TDSP_CORE_INST_DECODE_INST/RC_CG_HIER_INST33/RC_CGIC_INST/E]  \
  [get_pins TDSP_CORE_INST_EXECUTE_INST_RC_CG_HIER_INST3/enable]  \
  [get_pins TDSP_CORE_INST_EXECUTE_INST_RC_CG_HIER_INST3/RC_CGIC_INST/E]  \
  [get_pins TDSP_CORE_INST_EXECUTE_INST_RC_CG_HIER_INST4/enable]  \
  [get_pins TDSP_CORE_INST_EXECUTE_INST_RC_CG_HIER_INST4/RC_CGIC_INST/E]  \
  [get_pins TDSP_CORE_INST_EXECUTE_INST_RC_CG_HIER_INST5/enable]  \
  [get_pins TDSP_CORE_INST_EXECUTE_INST_RC_CG_HIER_INST5/RC_CGIC_INST/E]  \
  [get_pins TDSP_CORE_INST_EXECUTE_INST_RC_CG_HIER_INST6/enable]  \
  [get_pins TDSP_CORE_INST_EXECUTE_INST_RC_CG_HIER_INST6/RC_CGIC_INST/E]  \
  [get_pins TDSP_CORE_INST_EXECUTE_INST_RC_CG_HIER_INST7/enable]  \
  [get_pins TDSP_CORE_INST_EXECUTE_INST_RC_CG_HIER_INST7/RC_CGIC_INST/E]  \
  [get_pins TDSP_CORE_INST_EXECUTE_INST_RC_CG_HIER_INST8/enable]  \
  [get_pins TDSP_CORE_INST_EXECUTE_INST_RC_CG_HIER_INST8/RC_CGIC_INST/E]  \
  [get_pins TDSP_CORE_INST_EXECUTE_INST_RC_CG_HIER_INST9/enable]  \
  [get_pins TDSP_CORE_INST_EXECUTE_INST_RC_CG_HIER_INST9/RC_CGIC_INST/E]  \
  [get_pins TDSP_CORE_INST_EXECUTE_INST_RC_CG_HIER_INST10/enable]  \
  [get_pins TDSP_CORE_INST_EXECUTE_INST_RC_CG_HIER_INST10/RC_CGIC_INST/E]  \
  [get_pins TDSP_CORE_INST_EXECUTE_INST_RC_CG_HIER_INST34/enable]  \
  [get_pins TDSP_CORE_INST_EXECUTE_INST_RC_CG_HIER_INST34/RC_CGIC_INST/E]  \
  [get_pins TDSP_CORE_INST_EXECUTE_INST_RC_CG_HIER_INST35/enable]  \
  [get_pins TDSP_CORE_INST_EXECUTE_INST_RC_CG_HIER_INST35/RC_CGIC_INST/E]  \
  [get_pins TDSP_CORE_INST_PORT_BUS_MACH_INST/RC_CG_HIER_INST11/enable]  \
  [get_pins TDSP_CORE_INST_PORT_BUS_MACH_INST/RC_CG_HIER_INST11/RC_CGIC_INST/E]  \
  [get_pins TDSP_CORE_INST_PROG_BUS_MACH_INST/RC_CG_HIER_INST13/enable]  \
  [get_pins TDSP_CORE_INST_PROG_BUS_MACH_INST/RC_CG_HIER_INST13/RC_CGIC_INST/E]  \
  [get_pins TDSP_CORE_INST_TDSP_CORE_MACH_INST/RC_CG_HIER_INST31/enable]  \
  [get_pins TDSP_CORE_INST_TDSP_CORE_MACH_INST/RC_CG_HIER_INST31/RC_CGIC_INST/E] ]
set_false_path -from [list \
  [get_ports reset]  \
  [get_ports test_mode] ]
set_false_path -through [get_pins PM_INST/clk_enable] -hold
set_clock_gating_check -setup 0.0 
set_input_delay -clock [get_clocks refclk] -add_delay 0.3 [get_ports ibias]
set_input_delay -clock [get_clocks refclk] -add_delay 0.3 [get_ports pllrst]
set_input_delay -clock [get_clocks refclk] -add_delay 0.3 [get_ports spi_fs]
set_input_delay -clock [get_clocks refclk] -add_delay 0.3 [get_ports spi_data]
set_input_delay -clock [get_clocks refclk] -add_delay 0.3 [get_ports test_mode]
set_input_delay -clock [get_clocks refclk] -add_delay 0.3 [get_ports scan_clk]
set_input_delay -clock [get_clocks refclk] -add_delay 0.3 [get_ports scan_en]
set_input_delay -clock [get_clocks refclk] -add_delay 0.3 [get_ports {port_pad_data_in[0]}]
set_input_delay -clock [get_clocks refclk] -add_delay 0.3 [get_ports {port_pad_data_in[1]}]
set_input_delay -clock [get_clocks refclk] -add_delay 0.3 [get_ports {port_pad_data_in[2]}]
set_input_delay -clock [get_clocks refclk] -add_delay 0.3 [get_ports {port_pad_data_in[3]}]
set_input_delay -clock [get_clocks refclk] -add_delay 0.3 [get_ports {port_pad_data_in[4]}]
set_input_delay -clock [get_clocks refclk] -add_delay 0.3 [get_ports {port_pad_data_in[5]}]
set_input_delay -clock [get_clocks refclk] -add_delay 0.3 [get_ports {port_pad_data_in[6]}]
set_input_delay -clock [get_clocks refclk] -add_delay 0.3 [get_ports {port_pad_data_in[7]}]
set_input_delay -clock [get_clocks refclk] -add_delay 0.3 [get_ports {port_pad_data_in[8]}]
set_input_delay -clock [get_clocks refclk] -add_delay 0.3 [get_ports {port_pad_data_in[9]}]
set_input_delay -clock [get_clocks refclk] -add_delay 0.3 [get_ports {port_pad_data_in[10]}]
set_input_delay -clock [get_clocks refclk] -add_delay 0.3 [get_ports {port_pad_data_in[11]}]
set_input_delay -clock [get_clocks refclk] -add_delay 0.3 [get_ports {port_pad_data_in[12]}]
set_input_delay -clock [get_clocks refclk] -add_delay 0.3 [get_ports {port_pad_data_in[13]}]
set_input_delay -clock [get_clocks refclk] -add_delay 0.3 [get_ports {port_pad_data_in[14]}]
set_input_delay -clock [get_clocks refclk] -add_delay 0.3 [get_ports {port_pad_data_in[15]}]
set_input_delay -clock [get_clocks refclk] -add_delay 0.3 [get_ports int]
set_input_delay -clock [get_clocks refclk] -add_delay 0.3 [get_ports reset]
set_output_delay -clock [get_clocks refclk] -add_delay 0.3 [get_ports vcom]
set_output_delay -clock [get_clocks refclk] -add_delay 0.3 [get_ports vcop]
set_output_delay -clock [get_clocks refclk] -add_delay 0.3 [get_ports {port_pad_data_out[0]}]
set_output_delay -clock [get_clocks refclk] -add_delay 0.3 [get_ports {port_pad_data_out[1]}]
set_output_delay -clock [get_clocks refclk] -add_delay 0.3 [get_ports {port_pad_data_out[2]}]
set_output_delay -clock [get_clocks refclk] -add_delay 0.3 [get_ports {port_pad_data_out[3]}]
set_output_delay -clock [get_clocks refclk] -add_delay 0.3 [get_ports {port_pad_data_out[4]}]
set_output_delay -clock [get_clocks refclk] -add_delay 0.3 [get_ports {port_pad_data_out[5]}]
set_output_delay -clock [get_clocks refclk] -add_delay 0.3 [get_ports {port_pad_data_out[6]}]
set_output_delay -clock [get_clocks refclk] -add_delay 0.3 [get_ports {port_pad_data_out[7]}]
set_output_delay -clock [get_clocks refclk] -add_delay 0.3 [get_ports {port_pad_data_out[8]}]
set_output_delay -clock [get_clocks refclk] -add_delay 0.3 [get_ports {port_pad_data_out[9]}]
set_output_delay -clock [get_clocks refclk] -add_delay 0.3 [get_ports {port_pad_data_out[10]}]
set_output_delay -clock [get_clocks refclk] -add_delay 0.3 [get_ports {port_pad_data_out[11]}]
set_output_delay -clock [get_clocks refclk] -add_delay 0.3 [get_ports {port_pad_data_out[12]}]
set_output_delay -clock [get_clocks refclk] -add_delay 0.3 [get_ports {port_pad_data_out[13]}]
set_output_delay -clock [get_clocks refclk] -add_delay 0.3 [get_ports {port_pad_data_out[14]}]
set_output_delay -clock [get_clocks refclk] -add_delay 0.3 [get_ports {port_pad_data_out[15]}]
set_output_delay -clock [get_clocks refclk] -add_delay 0.3 [get_ports tdigit_flag]
set_output_delay -clock [get_clocks refclk] -add_delay 0.3 [get_ports {tdigit[0]}]
set_output_delay -clock [get_clocks refclk] -add_delay 0.3 [get_ports {tdigit[1]}]
set_output_delay -clock [get_clocks refclk] -add_delay 0.3 [get_ports {tdigit[2]}]
set_output_delay -clock [get_clocks refclk] -add_delay 0.3 [get_ports {tdigit[3]}]
set_output_delay -clock [get_clocks refclk] -add_delay 0.3 [get_ports {tdigit[4]}]
set_output_delay -clock [get_clocks refclk] -add_delay 0.3 [get_ports {tdigit[5]}]
set_output_delay -clock [get_clocks refclk] -add_delay 0.3 [get_ports {tdigit[6]}]
set_output_delay -clock [get_clocks refclk] -add_delay 0.3 [get_ports {tdigit[7]}]
set_input_delay -clock [get_clocks m_clk] -add_delay 0.3 [get_ports ibias]
set_input_delay -clock [get_clocks m_clk] -add_delay 0.3 [get_ports pllrst]
set_input_delay -clock [get_clocks m_clk] -add_delay 0.3 [get_ports spi_fs]
set_input_delay -clock [get_clocks m_clk] -add_delay 0.3 [get_ports spi_data]
set_input_delay -clock [get_clocks m_clk] -add_delay 0.3 [get_ports test_mode]
set_input_delay -clock [get_clocks m_clk] -add_delay 0.3 [get_ports scan_clk]
set_input_delay -clock [get_clocks m_clk] -add_delay 0.3 [get_ports scan_en]
set_input_delay -clock [get_clocks m_clk] -add_delay 0.3 [get_ports {port_pad_data_in[0]}]
set_input_delay -clock [get_clocks m_clk] -add_delay 0.3 [get_ports {port_pad_data_in[1]}]
set_input_delay -clock [get_clocks m_clk] -add_delay 0.3 [get_ports {port_pad_data_in[2]}]
set_input_delay -clock [get_clocks m_clk] -add_delay 0.3 [get_ports {port_pad_data_in[3]}]
set_input_delay -clock [get_clocks m_clk] -add_delay 0.3 [get_ports {port_pad_data_in[4]}]
set_input_delay -clock [get_clocks m_clk] -add_delay 0.3 [get_ports {port_pad_data_in[5]}]
set_input_delay -clock [get_clocks m_clk] -add_delay 0.3 [get_ports {port_pad_data_in[6]}]
set_input_delay -clock [get_clocks m_clk] -add_delay 0.3 [get_ports {port_pad_data_in[7]}]
set_input_delay -clock [get_clocks m_clk] -add_delay 0.3 [get_ports {port_pad_data_in[8]}]
set_input_delay -clock [get_clocks m_clk] -add_delay 0.3 [get_ports {port_pad_data_in[9]}]
set_input_delay -clock [get_clocks m_clk] -add_delay 0.3 [get_ports {port_pad_data_in[10]}]
set_input_delay -clock [get_clocks m_clk] -add_delay 0.3 [get_ports {port_pad_data_in[11]}]
set_input_delay -clock [get_clocks m_clk] -add_delay 0.3 [get_ports {port_pad_data_in[12]}]
set_input_delay -clock [get_clocks m_clk] -add_delay 0.3 [get_ports {port_pad_data_in[13]}]
set_input_delay -clock [get_clocks m_clk] -add_delay 0.3 [get_ports {port_pad_data_in[14]}]
set_input_delay -clock [get_clocks m_clk] -add_delay 0.3 [get_ports {port_pad_data_in[15]}]
set_input_delay -clock [get_clocks m_clk] -add_delay 0.3 [get_ports int]
set_input_delay -clock [get_clocks m_clk] -add_delay 0.3 [get_ports reset]
set_output_delay -clock [get_clocks m_clk] -add_delay 0.3 [get_ports vcom]
set_output_delay -clock [get_clocks m_clk] -add_delay 0.3 [get_ports vcop]
set_output_delay -clock [get_clocks m_clk] -add_delay 0.3 [get_ports {port_pad_data_out[0]}]
set_output_delay -clock [get_clocks m_clk] -add_delay 0.3 [get_ports {port_pad_data_out[1]}]
set_output_delay -clock [get_clocks m_clk] -add_delay 0.3 [get_ports {port_pad_data_out[2]}]
set_output_delay -clock [get_clocks m_clk] -add_delay 0.3 [get_ports {port_pad_data_out[3]}]
set_output_delay -clock [get_clocks m_clk] -add_delay 0.3 [get_ports {port_pad_data_out[4]}]
set_output_delay -clock [get_clocks m_clk] -add_delay 0.3 [get_ports {port_pad_data_out[5]}]
set_output_delay -clock [get_clocks m_clk] -add_delay 0.3 [get_ports {port_pad_data_out[6]}]
set_output_delay -clock [get_clocks m_clk] -add_delay 0.3 [get_ports {port_pad_data_out[7]}]
set_output_delay -clock [get_clocks m_clk] -add_delay 0.3 [get_ports {port_pad_data_out[8]}]
set_output_delay -clock [get_clocks m_clk] -add_delay 0.3 [get_ports {port_pad_data_out[9]}]
set_output_delay -clock [get_clocks m_clk] -add_delay 0.3 [get_ports {port_pad_data_out[10]}]
set_output_delay -clock [get_clocks m_clk] -add_delay 0.3 [get_ports {port_pad_data_out[11]}]
set_output_delay -clock [get_clocks m_clk] -add_delay 0.3 [get_ports {port_pad_data_out[12]}]
set_output_delay -clock [get_clocks m_clk] -add_delay 0.3 [get_ports {port_pad_data_out[13]}]
set_output_delay -clock [get_clocks m_clk] -add_delay 0.3 [get_ports {port_pad_data_out[14]}]
set_output_delay -clock [get_clocks m_clk] -add_delay 0.3 [get_ports {port_pad_data_out[15]}]
set_output_delay -clock [get_clocks m_clk] -add_delay 0.3 [get_ports tdigit_flag]
set_output_delay -clock [get_clocks m_clk] -add_delay 0.3 [get_ports {tdigit[0]}]
set_output_delay -clock [get_clocks m_clk] -add_delay 0.3 [get_ports {tdigit[1]}]
set_output_delay -clock [get_clocks m_clk] -add_delay 0.3 [get_ports {tdigit[2]}]
set_output_delay -clock [get_clocks m_clk] -add_delay 0.3 [get_ports {tdigit[3]}]
set_output_delay -clock [get_clocks m_clk] -add_delay 0.3 [get_ports {tdigit[4]}]
set_output_delay -clock [get_clocks m_clk] -add_delay 0.3 [get_ports {tdigit[5]}]
set_output_delay -clock [get_clocks m_clk] -add_delay 0.3 [get_ports {tdigit[6]}]
set_output_delay -clock [get_clocks m_clk] -add_delay 0.3 [get_ports {tdigit[7]}]
set_input_delay -clock [get_clocks m_rcc_clk] -add_delay 0.3 [get_ports ibias]
set_input_delay -clock [get_clocks m_rcc_clk] -add_delay 0.3 [get_ports pllrst]
set_input_delay -clock [get_clocks m_rcc_clk] -add_delay 0.3 [get_ports spi_fs]
set_input_delay -clock [get_clocks m_rcc_clk] -add_delay 0.3 [get_ports spi_data]
set_input_delay -clock [get_clocks m_rcc_clk] -add_delay 0.3 [get_ports test_mode]
set_input_delay -clock [get_clocks m_rcc_clk] -add_delay 0.3 [get_ports scan_clk]
set_input_delay -clock [get_clocks m_rcc_clk] -add_delay 0.3 [get_ports scan_en]
set_input_delay -clock [get_clocks m_rcc_clk] -add_delay 0.3 [get_ports {port_pad_data_in[0]}]
set_input_delay -clock [get_clocks m_rcc_clk] -add_delay 0.3 [get_ports {port_pad_data_in[1]}]
set_input_delay -clock [get_clocks m_rcc_clk] -add_delay 0.3 [get_ports {port_pad_data_in[2]}]
set_input_delay -clock [get_clocks m_rcc_clk] -add_delay 0.3 [get_ports {port_pad_data_in[3]}]
set_input_delay -clock [get_clocks m_rcc_clk] -add_delay 0.3 [get_ports {port_pad_data_in[4]}]
set_input_delay -clock [get_clocks m_rcc_clk] -add_delay 0.3 [get_ports {port_pad_data_in[5]}]
set_input_delay -clock [get_clocks m_rcc_clk] -add_delay 0.3 [get_ports {port_pad_data_in[6]}]
set_input_delay -clock [get_clocks m_rcc_clk] -add_delay 0.3 [get_ports {port_pad_data_in[7]}]
set_input_delay -clock [get_clocks m_rcc_clk] -add_delay 0.3 [get_ports {port_pad_data_in[8]}]
set_input_delay -clock [get_clocks m_rcc_clk] -add_delay 0.3 [get_ports {port_pad_data_in[9]}]
set_input_delay -clock [get_clocks m_rcc_clk] -add_delay 0.3 [get_ports {port_pad_data_in[10]}]
set_input_delay -clock [get_clocks m_rcc_clk] -add_delay 0.3 [get_ports {port_pad_data_in[11]}]
set_input_delay -clock [get_clocks m_rcc_clk] -add_delay 0.3 [get_ports {port_pad_data_in[12]}]
set_input_delay -clock [get_clocks m_rcc_clk] -add_delay 0.3 [get_ports {port_pad_data_in[13]}]
set_input_delay -clock [get_clocks m_rcc_clk] -add_delay 0.3 [get_ports {port_pad_data_in[14]}]
set_input_delay -clock [get_clocks m_rcc_clk] -add_delay 0.3 [get_ports {port_pad_data_in[15]}]
set_input_delay -clock [get_clocks m_rcc_clk] -add_delay 0.3 [get_ports int]
set_input_delay -clock [get_clocks m_rcc_clk] -add_delay 0.3 [get_ports reset]
set_output_delay -clock [get_clocks m_rcc_clk] -add_delay 0.3 [get_ports vcom]
set_output_delay -clock [get_clocks m_rcc_clk] -add_delay 0.3 [get_ports vcop]
set_output_delay -clock [get_clocks m_rcc_clk] -add_delay 0.3 [get_ports {port_pad_data_out[0]}]
set_output_delay -clock [get_clocks m_rcc_clk] -add_delay 0.3 [get_ports {port_pad_data_out[1]}]
set_output_delay -clock [get_clocks m_rcc_clk] -add_delay 0.3 [get_ports {port_pad_data_out[2]}]
set_output_delay -clock [get_clocks m_rcc_clk] -add_delay 0.3 [get_ports {port_pad_data_out[3]}]
set_output_delay -clock [get_clocks m_rcc_clk] -add_delay 0.3 [get_ports {port_pad_data_out[4]}]
set_output_delay -clock [get_clocks m_rcc_clk] -add_delay 0.3 [get_ports {port_pad_data_out[5]}]
set_output_delay -clock [get_clocks m_rcc_clk] -add_delay 0.3 [get_ports {port_pad_data_out[6]}]
set_output_delay -clock [get_clocks m_rcc_clk] -add_delay 0.3 [get_ports {port_pad_data_out[7]}]
set_output_delay -clock [get_clocks m_rcc_clk] -add_delay 0.3 [get_ports {port_pad_data_out[8]}]
set_output_delay -clock [get_clocks m_rcc_clk] -add_delay 0.3 [get_ports {port_pad_data_out[9]}]
set_output_delay -clock [get_clocks m_rcc_clk] -add_delay 0.3 [get_ports {port_pad_data_out[10]}]
set_output_delay -clock [get_clocks m_rcc_clk] -add_delay 0.3 [get_ports {port_pad_data_out[11]}]
set_output_delay -clock [get_clocks m_rcc_clk] -add_delay 0.3 [get_ports {port_pad_data_out[12]}]
set_output_delay -clock [get_clocks m_rcc_clk] -add_delay 0.3 [get_ports {port_pad_data_out[13]}]
set_output_delay -clock [get_clocks m_rcc_clk] -add_delay 0.3 [get_ports {port_pad_data_out[14]}]
set_output_delay -clock [get_clocks m_rcc_clk] -add_delay 0.3 [get_ports {port_pad_data_out[15]}]
set_output_delay -clock [get_clocks m_rcc_clk] -add_delay 0.3 [get_ports tdigit_flag]
set_output_delay -clock [get_clocks m_rcc_clk] -add_delay 0.3 [get_ports {tdigit[0]}]
set_output_delay -clock [get_clocks m_rcc_clk] -add_delay 0.3 [get_ports {tdigit[1]}]
set_output_delay -clock [get_clocks m_rcc_clk] -add_delay 0.3 [get_ports {tdigit[2]}]
set_output_delay -clock [get_clocks m_rcc_clk] -add_delay 0.3 [get_ports {tdigit[3]}]
set_output_delay -clock [get_clocks m_rcc_clk] -add_delay 0.3 [get_ports {tdigit[4]}]
set_output_delay -clock [get_clocks m_rcc_clk] -add_delay 0.3 [get_ports {tdigit[5]}]
set_output_delay -clock [get_clocks m_rcc_clk] -add_delay 0.3 [get_ports {tdigit[6]}]
set_output_delay -clock [get_clocks m_rcc_clk] -add_delay 0.3 [get_ports {tdigit[7]}]
set_input_delay -clock [get_clocks m_spi_clk] -add_delay 0.3 [get_ports ibias]
set_input_delay -clock [get_clocks m_spi_clk] -add_delay 0.3 [get_ports pllrst]
set_input_delay -clock [get_clocks m_spi_clk] -add_delay 0.3 [get_ports spi_fs]
set_input_delay -clock [get_clocks m_spi_clk] -add_delay 0.3 [get_ports spi_data]
set_input_delay -clock [get_clocks m_spi_clk] -add_delay 0.3 [get_ports test_mode]
set_input_delay -clock [get_clocks m_spi_clk] -add_delay 0.3 [get_ports scan_clk]
set_input_delay -clock [get_clocks m_spi_clk] -add_delay 0.3 [get_ports scan_en]
set_input_delay -clock [get_clocks m_spi_clk] -add_delay 0.3 [get_ports {port_pad_data_in[0]}]
set_input_delay -clock [get_clocks m_spi_clk] -add_delay 0.3 [get_ports {port_pad_data_in[1]}]
set_input_delay -clock [get_clocks m_spi_clk] -add_delay 0.3 [get_ports {port_pad_data_in[2]}]
set_input_delay -clock [get_clocks m_spi_clk] -add_delay 0.3 [get_ports {port_pad_data_in[3]}]
set_input_delay -clock [get_clocks m_spi_clk] -add_delay 0.3 [get_ports {port_pad_data_in[4]}]
set_input_delay -clock [get_clocks m_spi_clk] -add_delay 0.3 [get_ports {port_pad_data_in[5]}]
set_input_delay -clock [get_clocks m_spi_clk] -add_delay 0.3 [get_ports {port_pad_data_in[6]}]
set_input_delay -clock [get_clocks m_spi_clk] -add_delay 0.3 [get_ports {port_pad_data_in[7]}]
set_input_delay -clock [get_clocks m_spi_clk] -add_delay 0.3 [get_ports {port_pad_data_in[8]}]
set_input_delay -clock [get_clocks m_spi_clk] -add_delay 0.3 [get_ports {port_pad_data_in[9]}]
set_input_delay -clock [get_clocks m_spi_clk] -add_delay 0.3 [get_ports {port_pad_data_in[10]}]
set_input_delay -clock [get_clocks m_spi_clk] -add_delay 0.3 [get_ports {port_pad_data_in[11]}]
set_input_delay -clock [get_clocks m_spi_clk] -add_delay 0.3 [get_ports {port_pad_data_in[12]}]
set_input_delay -clock [get_clocks m_spi_clk] -add_delay 0.3 [get_ports {port_pad_data_in[13]}]
set_input_delay -clock [get_clocks m_spi_clk] -add_delay 0.3 [get_ports {port_pad_data_in[14]}]
set_input_delay -clock [get_clocks m_spi_clk] -add_delay 0.3 [get_ports {port_pad_data_in[15]}]
set_input_delay -clock [get_clocks m_spi_clk] -add_delay 0.3 [get_ports int]
set_input_delay -clock [get_clocks m_spi_clk] -add_delay 0.3 [get_ports reset]
set_output_delay -clock [get_clocks m_spi_clk] -add_delay 0.3 [get_ports vcom]
set_output_delay -clock [get_clocks m_spi_clk] -add_delay 0.3 [get_ports vcop]
set_output_delay -clock [get_clocks m_spi_clk] -add_delay 0.3 [get_ports {port_pad_data_out[0]}]
set_output_delay -clock [get_clocks m_spi_clk] -add_delay 0.3 [get_ports {port_pad_data_out[1]}]
set_output_delay -clock [get_clocks m_spi_clk] -add_delay 0.3 [get_ports {port_pad_data_out[2]}]
set_output_delay -clock [get_clocks m_spi_clk] -add_delay 0.3 [get_ports {port_pad_data_out[3]}]
set_output_delay -clock [get_clocks m_spi_clk] -add_delay 0.3 [get_ports {port_pad_data_out[4]}]
set_output_delay -clock [get_clocks m_spi_clk] -add_delay 0.3 [get_ports {port_pad_data_out[5]}]
set_output_delay -clock [get_clocks m_spi_clk] -add_delay 0.3 [get_ports {port_pad_data_out[6]}]
set_output_delay -clock [get_clocks m_spi_clk] -add_delay 0.3 [get_ports {port_pad_data_out[7]}]
set_output_delay -clock [get_clocks m_spi_clk] -add_delay 0.3 [get_ports {port_pad_data_out[8]}]
set_output_delay -clock [get_clocks m_spi_clk] -add_delay 0.3 [get_ports {port_pad_data_out[9]}]
set_output_delay -clock [get_clocks m_spi_clk] -add_delay 0.3 [get_ports {port_pad_data_out[10]}]
set_output_delay -clock [get_clocks m_spi_clk] -add_delay 0.3 [get_ports {port_pad_data_out[11]}]
set_output_delay -clock [get_clocks m_spi_clk] -add_delay 0.3 [get_ports {port_pad_data_out[12]}]
set_output_delay -clock [get_clocks m_spi_clk] -add_delay 0.3 [get_ports {port_pad_data_out[13]}]
set_output_delay -clock [get_clocks m_spi_clk] -add_delay 0.3 [get_ports {port_pad_data_out[14]}]
set_output_delay -clock [get_clocks m_spi_clk] -add_delay 0.3 [get_ports {port_pad_data_out[15]}]
set_output_delay -clock [get_clocks m_spi_clk] -add_delay 0.3 [get_ports tdigit_flag]
set_output_delay -clock [get_clocks m_spi_clk] -add_delay 0.3 [get_ports {tdigit[0]}]
set_output_delay -clock [get_clocks m_spi_clk] -add_delay 0.3 [get_ports {tdigit[1]}]
set_output_delay -clock [get_clocks m_spi_clk] -add_delay 0.3 [get_ports {tdigit[2]}]
set_output_delay -clock [get_clocks m_spi_clk] -add_delay 0.3 [get_ports {tdigit[3]}]
set_output_delay -clock [get_clocks m_spi_clk] -add_delay 0.3 [get_ports {tdigit[4]}]
set_output_delay -clock [get_clocks m_spi_clk] -add_delay 0.3 [get_ports {tdigit[5]}]
set_output_delay -clock [get_clocks m_spi_clk] -add_delay 0.3 [get_ports {tdigit[6]}]
set_output_delay -clock [get_clocks m_spi_clk] -add_delay 0.3 [get_ports {tdigit[7]}]
set_input_delay -clock [get_clocks m_dsram_clk] -add_delay 0.3 [get_ports ibias]
set_input_delay -clock [get_clocks m_dsram_clk] -add_delay 0.3 [get_ports pllrst]
set_input_delay -clock [get_clocks m_dsram_clk] -add_delay 0.3 [get_ports spi_fs]
set_input_delay -clock [get_clocks m_dsram_clk] -add_delay 0.3 [get_ports spi_data]
set_input_delay -clock [get_clocks m_dsram_clk] -add_delay 0.3 [get_ports test_mode]
set_input_delay -clock [get_clocks m_dsram_clk] -add_delay 0.3 [get_ports scan_clk]
set_input_delay -clock [get_clocks m_dsram_clk] -add_delay 0.3 [get_ports scan_en]
set_input_delay -clock [get_clocks m_dsram_clk] -add_delay 0.3 [get_ports {port_pad_data_in[0]}]
set_input_delay -clock [get_clocks m_dsram_clk] -add_delay 0.3 [get_ports {port_pad_data_in[1]}]
set_input_delay -clock [get_clocks m_dsram_clk] -add_delay 0.3 [get_ports {port_pad_data_in[2]}]
set_input_delay -clock [get_clocks m_dsram_clk] -add_delay 0.3 [get_ports {port_pad_data_in[3]}]
set_input_delay -clock [get_clocks m_dsram_clk] -add_delay 0.3 [get_ports {port_pad_data_in[4]}]
set_input_delay -clock [get_clocks m_dsram_clk] -add_delay 0.3 [get_ports {port_pad_data_in[5]}]
set_input_delay -clock [get_clocks m_dsram_clk] -add_delay 0.3 [get_ports {port_pad_data_in[6]}]
set_input_delay -clock [get_clocks m_dsram_clk] -add_delay 0.3 [get_ports {port_pad_data_in[7]}]
set_input_delay -clock [get_clocks m_dsram_clk] -add_delay 0.3 [get_ports {port_pad_data_in[8]}]
set_input_delay -clock [get_clocks m_dsram_clk] -add_delay 0.3 [get_ports {port_pad_data_in[9]}]
set_input_delay -clock [get_clocks m_dsram_clk] -add_delay 0.3 [get_ports {port_pad_data_in[10]}]
set_input_delay -clock [get_clocks m_dsram_clk] -add_delay 0.3 [get_ports {port_pad_data_in[11]}]
set_input_delay -clock [get_clocks m_dsram_clk] -add_delay 0.3 [get_ports {port_pad_data_in[12]}]
set_input_delay -clock [get_clocks m_dsram_clk] -add_delay 0.3 [get_ports {port_pad_data_in[13]}]
set_input_delay -clock [get_clocks m_dsram_clk] -add_delay 0.3 [get_ports {port_pad_data_in[14]}]
set_input_delay -clock [get_clocks m_dsram_clk] -add_delay 0.3 [get_ports {port_pad_data_in[15]}]
set_input_delay -clock [get_clocks m_dsram_clk] -add_delay 0.3 [get_ports int]
set_input_delay -clock [get_clocks m_dsram_clk] -add_delay 0.3 [get_ports reset]
set_output_delay -clock [get_clocks m_dsram_clk] -add_delay 0.3 [get_ports vcom]
set_output_delay -clock [get_clocks m_dsram_clk] -add_delay 0.3 [get_ports vcop]
set_output_delay -clock [get_clocks m_dsram_clk] -add_delay 0.3 [get_ports {port_pad_data_out[0]}]
set_output_delay -clock [get_clocks m_dsram_clk] -add_delay 0.3 [get_ports {port_pad_data_out[1]}]
set_output_delay -clock [get_clocks m_dsram_clk] -add_delay 0.3 [get_ports {port_pad_data_out[2]}]
set_output_delay -clock [get_clocks m_dsram_clk] -add_delay 0.3 [get_ports {port_pad_data_out[3]}]
set_output_delay -clock [get_clocks m_dsram_clk] -add_delay 0.3 [get_ports {port_pad_data_out[4]}]
set_output_delay -clock [get_clocks m_dsram_clk] -add_delay 0.3 [get_ports {port_pad_data_out[5]}]
set_output_delay -clock [get_clocks m_dsram_clk] -add_delay 0.3 [get_ports {port_pad_data_out[6]}]
set_output_delay -clock [get_clocks m_dsram_clk] -add_delay 0.3 [get_ports {port_pad_data_out[7]}]
set_output_delay -clock [get_clocks m_dsram_clk] -add_delay 0.3 [get_ports {port_pad_data_out[8]}]
set_output_delay -clock [get_clocks m_dsram_clk] -add_delay 0.3 [get_ports {port_pad_data_out[9]}]
set_output_delay -clock [get_clocks m_dsram_clk] -add_delay 0.3 [get_ports {port_pad_data_out[10]}]
set_output_delay -clock [get_clocks m_dsram_clk] -add_delay 0.3 [get_ports {port_pad_data_out[11]}]
set_output_delay -clock [get_clocks m_dsram_clk] -add_delay 0.3 [get_ports {port_pad_data_out[12]}]
set_output_delay -clock [get_clocks m_dsram_clk] -add_delay 0.3 [get_ports {port_pad_data_out[13]}]
set_output_delay -clock [get_clocks m_dsram_clk] -add_delay 0.3 [get_ports {port_pad_data_out[14]}]
set_output_delay -clock [get_clocks m_dsram_clk] -add_delay 0.3 [get_ports {port_pad_data_out[15]}]
set_output_delay -clock [get_clocks m_dsram_clk] -add_delay 0.3 [get_ports tdigit_flag]
set_output_delay -clock [get_clocks m_dsram_clk] -add_delay 0.3 [get_ports {tdigit[0]}]
set_output_delay -clock [get_clocks m_dsram_clk] -add_delay 0.3 [get_ports {tdigit[1]}]
set_output_delay -clock [get_clocks m_dsram_clk] -add_delay 0.3 [get_ports {tdigit[2]}]
set_output_delay -clock [get_clocks m_dsram_clk] -add_delay 0.3 [get_ports {tdigit[3]}]
set_output_delay -clock [get_clocks m_dsram_clk] -add_delay 0.3 [get_ports {tdigit[4]}]
set_output_delay -clock [get_clocks m_dsram_clk] -add_delay 0.3 [get_ports {tdigit[5]}]
set_output_delay -clock [get_clocks m_dsram_clk] -add_delay 0.3 [get_ports {tdigit[6]}]
set_output_delay -clock [get_clocks m_dsram_clk] -add_delay 0.3 [get_ports {tdigit[7]}]
set_input_delay -clock [get_clocks m_ram_clk] -add_delay 0.3 [get_ports ibias]
set_input_delay -clock [get_clocks m_ram_clk] -add_delay 0.3 [get_ports pllrst]
set_input_delay -clock [get_clocks m_ram_clk] -add_delay 0.3 [get_ports spi_fs]
set_input_delay -clock [get_clocks m_ram_clk] -add_delay 0.3 [get_ports spi_data]
set_input_delay -clock [get_clocks m_ram_clk] -add_delay 0.3 [get_ports test_mode]
set_input_delay -clock [get_clocks m_ram_clk] -add_delay 0.3 [get_ports scan_clk]
set_input_delay -clock [get_clocks m_ram_clk] -add_delay 0.3 [get_ports scan_en]
set_input_delay -clock [get_clocks m_ram_clk] -add_delay 0.3 [get_ports {port_pad_data_in[0]}]
set_input_delay -clock [get_clocks m_ram_clk] -add_delay 0.3 [get_ports {port_pad_data_in[1]}]
set_input_delay -clock [get_clocks m_ram_clk] -add_delay 0.3 [get_ports {port_pad_data_in[2]}]
set_input_delay -clock [get_clocks m_ram_clk] -add_delay 0.3 [get_ports {port_pad_data_in[3]}]
set_input_delay -clock [get_clocks m_ram_clk] -add_delay 0.3 [get_ports {port_pad_data_in[4]}]
set_input_delay -clock [get_clocks m_ram_clk] -add_delay 0.3 [get_ports {port_pad_data_in[5]}]
set_input_delay -clock [get_clocks m_ram_clk] -add_delay 0.3 [get_ports {port_pad_data_in[6]}]
set_input_delay -clock [get_clocks m_ram_clk] -add_delay 0.3 [get_ports {port_pad_data_in[7]}]
set_input_delay -clock [get_clocks m_ram_clk] -add_delay 0.3 [get_ports {port_pad_data_in[8]}]
set_input_delay -clock [get_clocks m_ram_clk] -add_delay 0.3 [get_ports {port_pad_data_in[9]}]
set_input_delay -clock [get_clocks m_ram_clk] -add_delay 0.3 [get_ports {port_pad_data_in[10]}]
set_input_delay -clock [get_clocks m_ram_clk] -add_delay 0.3 [get_ports {port_pad_data_in[11]}]
set_input_delay -clock [get_clocks m_ram_clk] -add_delay 0.3 [get_ports {port_pad_data_in[12]}]
set_input_delay -clock [get_clocks m_ram_clk] -add_delay 0.3 [get_ports {port_pad_data_in[13]}]
set_input_delay -clock [get_clocks m_ram_clk] -add_delay 0.3 [get_ports {port_pad_data_in[14]}]
set_input_delay -clock [get_clocks m_ram_clk] -add_delay 0.3 [get_ports {port_pad_data_in[15]}]
set_input_delay -clock [get_clocks m_ram_clk] -add_delay 0.3 [get_ports int]
set_input_delay -clock [get_clocks m_ram_clk] -add_delay 0.3 [get_ports reset]
set_output_delay -clock [get_clocks m_ram_clk] -add_delay 0.3 [get_ports vcom]
set_output_delay -clock [get_clocks m_ram_clk] -add_delay 0.3 [get_ports vcop]
set_output_delay -clock [get_clocks m_ram_clk] -add_delay 0.3 [get_ports {port_pad_data_out[0]}]
set_output_delay -clock [get_clocks m_ram_clk] -add_delay 0.3 [get_ports {port_pad_data_out[1]}]
set_output_delay -clock [get_clocks m_ram_clk] -add_delay 0.3 [get_ports {port_pad_data_out[2]}]
set_output_delay -clock [get_clocks m_ram_clk] -add_delay 0.3 [get_ports {port_pad_data_out[3]}]
set_output_delay -clock [get_clocks m_ram_clk] -add_delay 0.3 [get_ports {port_pad_data_out[4]}]
set_output_delay -clock [get_clocks m_ram_clk] -add_delay 0.3 [get_ports {port_pad_data_out[5]}]
set_output_delay -clock [get_clocks m_ram_clk] -add_delay 0.3 [get_ports {port_pad_data_out[6]}]
set_output_delay -clock [get_clocks m_ram_clk] -add_delay 0.3 [get_ports {port_pad_data_out[7]}]
set_output_delay -clock [get_clocks m_ram_clk] -add_delay 0.3 [get_ports {port_pad_data_out[8]}]
set_output_delay -clock [get_clocks m_ram_clk] -add_delay 0.3 [get_ports {port_pad_data_out[9]}]
set_output_delay -clock [get_clocks m_ram_clk] -add_delay 0.3 [get_ports {port_pad_data_out[10]}]
set_output_delay -clock [get_clocks m_ram_clk] -add_delay 0.3 [get_ports {port_pad_data_out[11]}]
set_output_delay -clock [get_clocks m_ram_clk] -add_delay 0.3 [get_ports {port_pad_data_out[12]}]
set_output_delay -clock [get_clocks m_ram_clk] -add_delay 0.3 [get_ports {port_pad_data_out[13]}]
set_output_delay -clock [get_clocks m_ram_clk] -add_delay 0.3 [get_ports {port_pad_data_out[14]}]
set_output_delay -clock [get_clocks m_ram_clk] -add_delay 0.3 [get_ports {port_pad_data_out[15]}]
set_output_delay -clock [get_clocks m_ram_clk] -add_delay 0.3 [get_ports tdigit_flag]
set_output_delay -clock [get_clocks m_ram_clk] -add_delay 0.3 [get_ports {tdigit[0]}]
set_output_delay -clock [get_clocks m_ram_clk] -add_delay 0.3 [get_ports {tdigit[1]}]
set_output_delay -clock [get_clocks m_ram_clk] -add_delay 0.3 [get_ports {tdigit[2]}]
set_output_delay -clock [get_clocks m_ram_clk] -add_delay 0.3 [get_ports {tdigit[3]}]
set_output_delay -clock [get_clocks m_ram_clk] -add_delay 0.3 [get_ports {tdigit[4]}]
set_output_delay -clock [get_clocks m_ram_clk] -add_delay 0.3 [get_ports {tdigit[5]}]
set_output_delay -clock [get_clocks m_ram_clk] -add_delay 0.3 [get_ports {tdigit[6]}]
set_output_delay -clock [get_clocks m_ram_clk] -add_delay 0.3 [get_ports {tdigit[7]}]
set_input_delay -clock [get_clocks m_digit_clk] -add_delay 0.3 [get_ports ibias]
set_input_delay -clock [get_clocks m_digit_clk] -add_delay 0.3 [get_ports pllrst]
set_input_delay -clock [get_clocks m_digit_clk] -add_delay 0.3 [get_ports spi_fs]
set_input_delay -clock [get_clocks m_digit_clk] -add_delay 0.3 [get_ports spi_data]
set_input_delay -clock [get_clocks m_digit_clk] -add_delay 0.3 [get_ports test_mode]
set_input_delay -clock [get_clocks m_digit_clk] -add_delay 0.3 [get_ports scan_clk]
set_input_delay -clock [get_clocks m_digit_clk] -add_delay 0.3 [get_ports scan_en]
set_input_delay -clock [get_clocks m_digit_clk] -add_delay 0.3 [get_ports {port_pad_data_in[0]}]
set_input_delay -clock [get_clocks m_digit_clk] -add_delay 0.3 [get_ports {port_pad_data_in[1]}]
set_input_delay -clock [get_clocks m_digit_clk] -add_delay 0.3 [get_ports {port_pad_data_in[2]}]
set_input_delay -clock [get_clocks m_digit_clk] -add_delay 0.3 [get_ports {port_pad_data_in[3]}]
set_input_delay -clock [get_clocks m_digit_clk] -add_delay 0.3 [get_ports {port_pad_data_in[4]}]
set_input_delay -clock [get_clocks m_digit_clk] -add_delay 0.3 [get_ports {port_pad_data_in[5]}]
set_input_delay -clock [get_clocks m_digit_clk] -add_delay 0.3 [get_ports {port_pad_data_in[6]}]
set_input_delay -clock [get_clocks m_digit_clk] -add_delay 0.3 [get_ports {port_pad_data_in[7]}]
set_input_delay -clock [get_clocks m_digit_clk] -add_delay 0.3 [get_ports {port_pad_data_in[8]}]
set_input_delay -clock [get_clocks m_digit_clk] -add_delay 0.3 [get_ports {port_pad_data_in[9]}]
set_input_delay -clock [get_clocks m_digit_clk] -add_delay 0.3 [get_ports {port_pad_data_in[10]}]
set_input_delay -clock [get_clocks m_digit_clk] -add_delay 0.3 [get_ports {port_pad_data_in[11]}]
set_input_delay -clock [get_clocks m_digit_clk] -add_delay 0.3 [get_ports {port_pad_data_in[12]}]
set_input_delay -clock [get_clocks m_digit_clk] -add_delay 0.3 [get_ports {port_pad_data_in[13]}]
set_input_delay -clock [get_clocks m_digit_clk] -add_delay 0.3 [get_ports {port_pad_data_in[14]}]
set_input_delay -clock [get_clocks m_digit_clk] -add_delay 0.3 [get_ports {port_pad_data_in[15]}]
set_input_delay -clock [get_clocks m_digit_clk] -add_delay 0.3 [get_ports int]
set_input_delay -clock [get_clocks m_digit_clk] -add_delay 0.3 [get_ports reset]
set_output_delay -clock [get_clocks m_digit_clk] -add_delay 0.3 [get_ports vcom]
set_output_delay -clock [get_clocks m_digit_clk] -add_delay 0.3 [get_ports vcop]
set_output_delay -clock [get_clocks m_digit_clk] -add_delay 0.3 [get_ports {port_pad_data_out[0]}]
set_output_delay -clock [get_clocks m_digit_clk] -add_delay 0.3 [get_ports {port_pad_data_out[1]}]
set_output_delay -clock [get_clocks m_digit_clk] -add_delay 0.3 [get_ports {port_pad_data_out[2]}]
set_output_delay -clock [get_clocks m_digit_clk] -add_delay 0.3 [get_ports {port_pad_data_out[3]}]
set_output_delay -clock [get_clocks m_digit_clk] -add_delay 0.3 [get_ports {port_pad_data_out[4]}]
set_output_delay -clock [get_clocks m_digit_clk] -add_delay 0.3 [get_ports {port_pad_data_out[5]}]
set_output_delay -clock [get_clocks m_digit_clk] -add_delay 0.3 [get_ports {port_pad_data_out[6]}]
set_output_delay -clock [get_clocks m_digit_clk] -add_delay 0.3 [get_ports {port_pad_data_out[7]}]
set_output_delay -clock [get_clocks m_digit_clk] -add_delay 0.3 [get_ports {port_pad_data_out[8]}]
set_output_delay -clock [get_clocks m_digit_clk] -add_delay 0.3 [get_ports {port_pad_data_out[9]}]
set_output_delay -clock [get_clocks m_digit_clk] -add_delay 0.3 [get_ports {port_pad_data_out[10]}]
set_output_delay -clock [get_clocks m_digit_clk] -add_delay 0.3 [get_ports {port_pad_data_out[11]}]
set_output_delay -clock [get_clocks m_digit_clk] -add_delay 0.3 [get_ports {port_pad_data_out[12]}]
set_output_delay -clock [get_clocks m_digit_clk] -add_delay 0.3 [get_ports {port_pad_data_out[13]}]
set_output_delay -clock [get_clocks m_digit_clk] -add_delay 0.3 [get_ports {port_pad_data_out[14]}]
set_output_delay -clock [get_clocks m_digit_clk] -add_delay 0.3 [get_ports {port_pad_data_out[15]}]
set_output_delay -clock [get_clocks m_digit_clk] -add_delay 0.3 [get_ports tdigit_flag]
set_output_delay -clock [get_clocks m_digit_clk] -add_delay 0.3 [get_ports {tdigit[0]}]
set_output_delay -clock [get_clocks m_digit_clk] -add_delay 0.3 [get_ports {tdigit[1]}]
set_output_delay -clock [get_clocks m_digit_clk] -add_delay 0.3 [get_ports {tdigit[2]}]
set_output_delay -clock [get_clocks m_digit_clk] -add_delay 0.3 [get_ports {tdigit[3]}]
set_output_delay -clock [get_clocks m_digit_clk] -add_delay 0.3 [get_ports {tdigit[4]}]
set_output_delay -clock [get_clocks m_digit_clk] -add_delay 0.3 [get_ports {tdigit[5]}]
set_output_delay -clock [get_clocks m_digit_clk] -add_delay 0.3 [get_ports {tdigit[6]}]
set_output_delay -clock [get_clocks m_digit_clk] -add_delay 0.3 [get_ports {tdigit[7]}]
set_max_fanout 15.000 [current_design]
set_max_transition 1.2 [current_design]
